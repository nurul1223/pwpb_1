<!DOCTYPE html>
<html>
<head>
	<title>Tugas PWPB</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
    <style type="text/css">
    	 * {
        margin:0; 
        padding:0;
    }

    nav {
        margin:auto;
        text-align: center;
        width: 100%;
        font-family: arial;
    } 

    nav ul {
        background:#37988e;
        padding: 0 20px;
        list-style: none;
        position: relative;
        display: inline-table;
        width: 100%;
     }

    nav ul li{
        float:left;
    }

    nav ul li:hover{
        background:#d68d9a;
    }

    nav ul li:hover a{
        color:#000;
    }

    nav ul li a{
        display: block;
        padding: 25px;
        color: #fff;
        text-decoration: none;
    }
    .footer{
    	padding: 10px;
    	background: #37988e;
    	text-align: center;
    }
    .k{
    	width: 59%;
    	padding: 300px;
    	background: #64feff;
    }
    </style>
</head>
<body>
<nav>
    <ul>
        <li><a href="">Home</a></li>
        <li><a href="anggota.php">tugas satu</a></li>
        <li><a href="#">tugas dua</a></li>
    </ul>
</nav>
	
	<div class="k">
	<br>
	<center><p> Hai!Selamat datang di website kami </p>
	<p> <h4>Kami dari kelas XI RPL 1 dan dari kelompok 7</h4></p>
    </center>
	</div>
	<div class="footer">
		Copyright &copy; 2019 Nurul, Tari, Purnomo
	</div>

</body>
</html>
