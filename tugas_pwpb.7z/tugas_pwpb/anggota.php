<?php
$anggota_pertama = "Nurul Yaqin";
$umur_pertama = 16;
$tinggi_badan_pertama = 152;
$hobby_pertama = "Membaca";

$anggota_kedua = "Dian Lestari";
$umur_kedua = 15;
$tinggi_badan_kedua = 150;
$hobby_kedua = "Menyanyi";

$anggota_ketiga = "Muhamad Rizky Purnomo";
$umur_ketiga = 16;
$tinggi_badan_ketiga = 140;
$hobby_ketiga = "Main cing ngumpet ";

$rata_rata = ($tinggi_badan_pertama + $tinggi_badan_kedua + $tinggi_badan_ketiga)/3;
?>
<!DOCTYPE html>
<html>
<head>
	<title>Tugas PWPB</title>
	<style type="text/css">
	 * {
        margin:0; 
        padding:0;
    }

    nav {
        margin:auto;
        text-align: center;
        width:100% ;
        font-family: arial;
    } 

    nav ul {
        background:#37988e;
        padding: 0 20px;
        list-style: none;
        position: relative;
        display: inline-table;
        width: 100%;
     }

    nav ul li{
        float:left;
    }

    nav ul li:hover{
        background:#d68d9a;
    }

    nav ul li:hover a{
        color:#000;
    }

    nav ul li a{
        display: block;
        padding: 25px;
        color: #fff;
        text-decoration: none;
    }

    .k{
    	width: 100%;
    	padding: 20px;
    	background: #64feff;
    }
</style>
</head>
<body>
	<nav>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="anggota.php">tugas satu</a></li>
        <li><a href="#">tugas dua</a></li>
    </ul>
</nav>
	<center>
<div class="card" style="margin: 20px;margin-left: 100px;">
			<p><img src="nurul.jpg" width="200px" height="200px" style="border-radius: 50%;">
			<br>
			<ul>
				
				Nama :<?php echo "$anggota_pertama"; ?> <br>
				Umur :<?php echo "$umur_pertama"; ?> Tahun<br>
				Tinggi Badan :<?php echo "$tinggi_badan_pertama"; ?> cm <br> 
				Hobi :<?php echo "$hobby_pertama"; ?><br>
					<br><br><br><br>
				<img src="tari.jpg" width="200px" height="200px" style="border-radius: 50%">
					</p>
			
			<ul>
				Nama :<?php echo "$anggota_kedua"; ?> <br>
				Umur :<?php echo "$umur_kedua"; ?> Tahun<br>
				Tinggi Badan :<?php echo "$tinggi_badan_kedua"; ?> cm <br> 
				Hobi :<?php echo "$hobby_kedua"; ?><br>
					<br><br><br><br>
				<img src="purno.jpg" width="200px" height="200px" style="border-radius: 50%">
			<br>
			<ul>
				Nama :<?php echo "$anggota_ketiga"; ?> <br>
				Umur :<?php echo "$umur_ketiga"; ?> Tahun<br>
				Tinggi Badan :<?php echo "$tinggi_badan_ketiga"; ?> cm <br> 
				Hobi :<?php echo "$hobby_ketiga"; ?><br>

</div>
	<h3>Rata-rata tinggi badan : <?php echo "$rata_rata"; ?> cm</h3>
		<br><br><br>
	
	<div class="k">
		<div class="footer">
		Copyright &copy; 2019 Nurul, Tari, Purnomo
	</div>
		</center>
	</div>
</body>
</html>